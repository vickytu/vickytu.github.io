<? include ("header.php"); ?>
				
	
			<div class="entry">
	
				<h2>404</h2>
				
				<?php if ( ($balloons_option['balloons_select-language'] == 'English') OR ($balloons_option['balloons_select-language'] == '') ) { ?>
				    <h3>Page not found.</h3>
				<?php } else { ?>
				    <h3>Seite nicht gefunden</h3>
				<?php } ?>
											
			</div> <!-- end .entry -->
			

<? include ("footer.php"); ?>