Balloons WordPress Theme

Version: 1.1
Released: January 2012

By Moargh.de
http://www.moargh.de

___



'Balloons' is a one-column layout with parallax-scrolling effect. It comes with a tiny color switcher and a three-column widgetized footer. It is responsive to your visitor�s screen size (computer / tablet / mobile phone) and a stylesheet for the WP-Pagenavi plugin is included; available in English and German.



Features
--------------

- Theme Options page for easy customization
- Two frontend languages: English / German
- Tiny color switcher
- Three column widgetized footer
- Stylesheet for WP-Pagenavi included
- Custom Menu
- Responsive design � adjusts to browser size / mobile versions
  ...



Installation
--------------

Use the installation tool in your WordPress (Appearance � Themes) backend or copy the folder 'balloons' in /wp-content/themes/ and activate it

Tested in the latest versions of Firefox, Safari, Chrome, Opera and Internet Explorer 8/9.