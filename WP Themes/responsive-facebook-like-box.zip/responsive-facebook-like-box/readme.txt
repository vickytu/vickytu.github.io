=== responsive-facebook-like-box ===
Contributors: Freewebmentor
Tags: facebook, likebox, facebook like, pages, facebook box , facebook like box
Requires at least: 3.0
Tested up to: 3.6


Responsible Facebook Like Box in your WordPress sidebar widgets.

== Description ==

It will display a more flexible and responsible Facebook Like Box in your WordPress sidebar widgets. More than that, it also enable to display in your code template. Facebook Like Box is a wordpress social plugin that enables Facebook Page owners to attract and gain Likes from their own website.

More info and screenshots  on  http://freewebmentor.com/facebook-like-box-wordpress.html


= Best Facebook Like Box widget  for WordPress =

    1.See how many users already like this Page, and which of their friends like it too
    3.Like the Page with only one click.
    4.No need any api key or application  id, only enter your facebook fan page URL.




Tags: facebook, likebox, facebook like, pages, facebook box , facebook like box

== Frequently Asked Questions ==



== Screenshots ==

http://freewebmentor.com/facebook-like-box-wordpress.html

== Changelog ==





== Upgrade Notice ==



