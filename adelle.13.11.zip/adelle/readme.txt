INSTALL
====================================================
1. Upload the theme folder via FTP to your wp-content/themes/ directory.
2. Go to your WordPress dashboard and select Appearance.
3. Activate Adelle theme.
4. Inside your WordPress dashboard, go to Appearance > Theme Options and configure them to your liking.