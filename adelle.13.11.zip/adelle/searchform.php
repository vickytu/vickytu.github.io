<form role="search" class="sideform" method="get" action="<?php echo esc_url( home_url() ); ?>">
  <fieldset>
  <input type="text" name="s" class="sidetext" size="15" title="<?php _e('Search','adelle-theme'); ?>" />
  <input type="submit" class="sidebutton" value="<?php _e('Search','adelle-theme'); ?>" />
  </fieldset>
</form>